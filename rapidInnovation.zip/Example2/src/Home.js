import React from 'react'
import './Home.css';
import homePageLogo from './assets/landkit.png';
// import NavBar from './Navbar';

function Home() {
    return (
        <div>
            <div className="container">
                <div className="helpText">
                    <h1 className="welcomeMessage">
                        Welcome to
                        <span className="text-primary"> Landkit</span>. 
                        <br /> Develop anything.
                    </h1> 
                    <p className="descriptionMsg">
                        Build a beautiful, modern website with flexible<br/> Bootstrap components built from scratch.
                    </p>
                </div>
                <div className="homepageImage">
                    <img src={homePageLogo} alt="homePageImage" style={{maxWidth: '100%' , maxHeight: '100%'}}/>
                </div>
            </div>
            <div className="card">
                <div >
                    <h3 className="cheading">Built for developers</h3>
                    <p className="cDescription">Landkit is built to make your life easier. Variables, build tooling, documentation, and reusable components.</p>
                </div>
                <div>
                    <h3 className="cheading">Designed to be modern</h3>
                    <p className="cDescription">Designed with the latest design trends in mind. Landkit feels modern, minimal, and beautiful.</p>
                </div>
                <div>
                    <h3 className="cheading">Documentation for everything</h3>
                    <p className="cDescription">Designed with the latest design trends in mind. Landkit feels modern, minimal, and beautiful.</p>
                </div>
            </div>
        </div>
    )
}

export default Home
