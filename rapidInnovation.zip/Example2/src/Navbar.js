import React from 'react';
import './NavbarStyle.css';

function NavBar() {
    return (
        <div>
                <div className="homeLogo">
                    <p className="logoText">Landkit.</p>
                </div>
                <div className="homeDiv">
                    <ul>
                        <li><a className="active" href="#home">Landings</a></li>
                        <li><a href="#news">Pages</a></li>
                        <li><a href="#contact">Account</a></li>
                        <li><a href="#about">Documentation</a></li>
                    </ul>
                </div>
        </div>
    )
}

export default NavBar
