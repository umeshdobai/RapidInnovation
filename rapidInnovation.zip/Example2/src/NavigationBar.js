import React from 'react';
import {Link} from 'react-router-dom';
import './NavbarStyle.css';

const listStyle = {
    ulStyle: {
        listStyleType: "none",
        display: "flex",
        width: "50%",
        justifyContent: "space-around",
        alignItems: "center",
    },
    liStyle: {
        display: 'block',
        paddingLeft: "2rem"
    },
    linkStyle:{
        display: "block",
        textAlign: "center",
        padding: "14px 16px",
        textDecoration: "none",
    }
}

function NavigationBar() {
    return (
        <nav className="nav">
                <div className="homeLogo">
                    <p className="logoText">Landkit.</p>
                </div>
                <div className="homeDiv">
                    <ul style={listStyle.ulStyle}>    
                        <li style={listStyle.liStyle}><Link to="/" style={listStyle.linkStyle}>Landings</Link></li>
                        <li style={listStyle.liStyle}><Link to="/" style={listStyle.linkStyle}>Pages</Link></li>
                        <li style={listStyle.liStyle}><Link to="/form" style={listStyle.linkStyle}>Account</Link></li>
                        <li style={listStyle.liStyle}><Link to="/" style={listStyle.linkStyle}>Documentation</Link></li>
                    </ul>
                </div>
        </nav>
    )
}

export default NavigationBar
