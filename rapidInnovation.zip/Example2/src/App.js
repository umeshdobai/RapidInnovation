import React,{Component} from 'react';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import NavigationBar from './NavigationBar';
import Form from './Form';
import Home from './Home';

class App extends Component{
  render(){
    return (
      <Router>
        <div className="App">
            <NavigationBar />
            <Switch>
              <Route exact path="/" component={Home} />
              <Route path="/form" component={Form} />
            </Switch>
        </div>
      </Router>
    );
  }
  
}

export default App;
